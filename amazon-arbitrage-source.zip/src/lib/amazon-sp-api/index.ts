import { AmazonSpApiClient } from './amazon-sp-api-client';
import { ProfitabilityService } from './profitability-service';
import { SP_API_CONFIG, PRICING_ENDPOINTS } from './sp-api-config';
import { D1Database } from '@cloudflare/workers-types';

/**
 * Main entry point for the Amazon SP API module
 * Exports all necessary components for pricing calculations and profitability analysis
 */

export { AmazonSpApiClient } from './amazon-sp-api-client';
export { ProfitabilityService } from './profitability-service';
export { SP_API_CONFIG, PRICING_ENDPOINTS } from './sp-api-config';

/**
 * Create a new Amazon SP API client
 * @param db - D1 database instance
 * @param credentials - Optional SP API credentials
 * @returns AmazonSpApiClient instance
 */
export function createAmazonSpApiClient(db: D1Database, credentials?: {
  refresh_token?: string;
  client_id?: string;
  client_secret?: string;
}): AmazonSpApiClient {
  return new AmazonSpApiClient(db, credentials);
}

/**
 * Create a new profitability service
 * @param db - D1 database instance
 * @returns ProfitabilityService instance
 */
export function createProfitabilityService(db: D1Database): ProfitabilityService {
  return new ProfitabilityService(db);
}

/**
 * Calculate profitability for a product found on an external website
 * @param db - D1 database instance
 * @param productId - Database ID of the product
 * @param websiteId - Database ID of the website
 * @returns Profitability calculation result
 */
export async function calculateProductProfitability(db: D1Database, productId: number, websiteId: number): Promise<{
  productId: number;
  websiteId: number;
  asin: string;
  sourcingPrice: number;
  amazonPrice: number;
  fees: number;
  profit: number;
  margin: number;
  isProfitable: boolean;
}> {
  const service = createProfitabilityService(db);
  await service.initialize();
  return await service.calculateProfitability(productId, websiteId);
}

/**
 * Find profitable products based on configured thresholds
 * @param db - D1 database instance
 * @param limit - Maximum number of products to return
 * @returns Array of profitable products
 */
export async function findProfitableProducts(db: D1Database, limit: number = 100): Promise<any[]> {
  const service = createProfitabilityService(db);
  await service.initialize();
  return await service.findProfitableProducts(limit);
}

/**
 * Store Amazon SP API credentials in the database
 * @param db - D1 database instance
 * @param credentials - SP API credentials
 */
export async function storeSpApiCredentials(db: D1Database, credentials: {
  refresh_token: string;
  client_id: string;
  client_secret: string;
}): Promise<void> {
  const service = createProfitabilityService(db);
  await service.storeCredentials(credentials);
}
