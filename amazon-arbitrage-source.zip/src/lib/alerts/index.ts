import { AlertService } from './alert-service';
import { EmailService } from './email-service';
import { ALERT_CONFIG } from './alert-config';
import { D1Database } from '@cloudflare/workers-types';

/**
 * Main entry point for the alerts module
 * Exports all necessary components for email alerts
 */

export { AlertService } from './alert-service';
export { EmailService } from './email-service';
export { ALERT_CONFIG } from './alert-config';

/**
 * Create a new alert service
 * @param db - D1 database instance
 * @returns AlertService instance
 */
export function createAlertService(db: D1Database): AlertService {
  return new AlertService(db);
}

/**
 * Create a new email service
 * @param db - D1 database instance
 * @returns EmailService instance
 */
export function createEmailService(db: D1Database): EmailService {
  return new EmailService(db);
}

/**
 * Initialize the alert system
 * @param db - D1 database instance
 */
export async function initializeAlertSystem(db: D1Database): Promise<void> {
  const service = createAlertService(db);
  await service.initialize();
}

/**
 * Store SendGrid API key in the database
 * @param db - D1 database instance
 * @param apiKey - SendGrid API key
 */
export async function storeApiKey(db: D1Database, apiKey: string): Promise<void> {
  const service = createEmailService(db);
  await service.storeApiKey(apiKey);
}

/**
 * Send alerts for all profitable opportunities
 * @param db - D1 database instance
 * @param limit - Maximum number of opportunities to alert
 * @returns Alert sending results
 */
export async function sendProfitableOpportunityAlerts(db: D1Database, limit: number = 10): Promise<{
  sent: number;
  failed: number;
}> {
  const service = createAlertService(db);
  await service.initialize();
  return await service.sendAllProfitableOpportunityAlerts(limit);
}

/**
 * Send a daily summary email with all profitable opportunities
 * @param db - D1 database instance
 * @returns Whether the email was sent successfully
 */
export async function sendDailySummaryEmail(db: D1Database): Promise<boolean> {
  const service = createAlertService(db);
  await service.initialize();
  return await service.sendDailySummaryEmail();
}
