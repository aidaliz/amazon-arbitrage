import { SchedulerService } from './scheduler-service';
import { MonitoringService } from './monitoring-service';
import { MONITORING_CONFIG } from './monitoring-config';
import { D1Database } from '@cloudflare/workers-types';

/**
 * Main entry point for the monitoring module
 * Exports all necessary components for tracking product prices and stock changes
 */

export { MonitoringService } from './monitoring-service';
export { SchedulerService } from './scheduler-service';
export { MONITORING_CONFIG } from './monitoring-config';

/**
 * Create a new monitoring service
 * @param db - D1 database instance
 * @returns MonitoringService instance
 */
export function createMonitoringService(db: D1Database): MonitoringService {
  return new MonitoringService(db);
}

/**
 * Create a new scheduler service
 * @param db - D1 database instance
 * @returns SchedulerService instance
 */
export function createSchedulerService(db: D1Database): SchedulerService {
  return new SchedulerService(db);
}

/**
 * Initialize the monitoring system
 * @param db - D1 database instance
 */
export async function initializeMonitoringSystem(db: D1Database): Promise<void> {
  const scheduler = createSchedulerService(db);
  await scheduler.initializeSchedulerTables();
}

/**
 * Run a complete monitoring cycle
 * @param db - D1 database instance
 * @returns Monitoring cycle results
 */
export async function runMonitoringCycle(db: D1Database): Promise<{
  websitesChecked: number;
  priceChanges: number;
  stockChanges: number;
  profitableOpportunities: number;
}> {
  const service = createMonitoringService(db);
  return await service.runMonitoringCycle();
}

/**
 * Process all due scheduled jobs
 * @param db - D1 database instance
 * @returns Job processing results
 */
export async function processScheduledJobs(db: D1Database): Promise<{
  processed: number;
  succeeded: number;
  failed: number;
  results: any[];
}> {
  const scheduler = createSchedulerService(db);
  return await scheduler.processAllDueJobs();
}

/**
 * Find profitable opportunities based on recent price changes
 * @param db - D1 database instance
 * @param limit - Maximum number of opportunities to return
 * @returns Array of profitable opportunities
 */
export async function findProfitableOpportunities(db: D1Database, limit: number = 100): Promise<any[]> {
  const service = createMonitoringService(db);
  return await service.findProfitableOpportunities(limit);
}

/**
 * Clean up old price history data
 * @param db - D1 database instance
 * @returns Cleanup results
 */
export async function cleanupOldData(db: D1Database): Promise<{
  priceHistoryDeleted: number;
  alertHistoryDeleted: number;
}> {
  const service = createMonitoringService(db);
  return await service.cleanupOldData();
}
