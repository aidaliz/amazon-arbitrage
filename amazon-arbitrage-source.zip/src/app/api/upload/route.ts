import { AppService } from '../../services/app-service';
import { D1Database } from '@cloudflare/workers-types';

/**
 * API route handler for processing uploaded CSV files
 */
export async function POST(request: Request) {
  try {
    // Get the database from the environment
    const db = (request as any).env.DB as D1Database;
    
    // Create app service
    const appService = new AppService(db);
    
    // Parse form data
    const formData = await request.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return new Response(JSON.stringify({
        success: false,
        message: 'No file provided'
      }), {
        status: 400,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    }
    
    // Read file content
    const csvContent = await file.text();
    
    // Process CSV
    const result = await appService.processAsinCsv(csvContent);
    
    // If successful, start crawling for a few ASINs immediately
    if (result.success && result.asinsProcessed > 0) {
      // Process up to 5 ASINs immediately for a responsive user experience
      appService.startCrawlingForAsins(5).catch(error => {
        console.error('Error starting initial crawling:', error);
      });
    }
    
    // Return response
    return new Response(JSON.stringify(result), {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Error processing CSV upload:', error);
    
    // Return error response
    return new Response(JSON.stringify({
      success: false,
      message: error.message || 'Unknown error'
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
}
