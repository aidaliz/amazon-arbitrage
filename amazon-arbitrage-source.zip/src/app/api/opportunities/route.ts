import { AppService } from '../../services/app-service';
import { D1Database } from '@cloudflare/workers-types';

/**
 * API route handler for retrieving profitable opportunities
 */
export async function GET(request: Request) {
  try {
    // Get the database from the environment
    const db = (request as any).env.DB as D1Database;
    
    // Create app service
    const appService = new AppService(db);
    
    // Get query parameters
    const url = new URL(request.url);
    const limitParam = url.searchParams.get('limit');
    const limit = limitParam ? parseInt(limitParam, 10) : 100;
    
    // Find profitable opportunities
    const opportunities = await appService.findProfitableOpportunities(limit);
    
    // Return response
    return new Response(JSON.stringify({
      success: true,
      count: opportunities.length,
      opportunities
    }), {
      headers: {
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Error retrieving profitable opportunities:', error);
    
    // Return error response
    return new Response(JSON.stringify({
      success: false,
      message: error.message || 'Unknown error'
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
}
