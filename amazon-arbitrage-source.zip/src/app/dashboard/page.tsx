import { AppService } from '../services/app-service';
import { D1Database } from '@cloudflare/workers-types';

export const runtime = 'edge';

export default async function Dashboard({ params }: { params: {} }) {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Amazon Arbitrage Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Upload ASINs</h2>
          <p className="text-gray-600 mb-4">
            Upload a CSV file containing ASINs from Keepa's Product Finder to start finding profitable opportunities.
          </p>
          <div className="mt-4">
            <UploadForm />
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">System Status</h2>
          <StatusPanel />
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <h2 className="text-xl font-semibold mb-4">Profitable Opportunities</h2>
        <OpportunitiesList />
      </div>
    </div>
  );
}

function UploadForm() {
  return (
    <form action="/api/upload" method="post" encType="multipart/form-data" className="space-y-4">
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
        <label htmlFor="file" className="cursor-pointer">
          <div className="text-gray-500 mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <p>Drag and drop your CSV file here, or click to browse</p>
          </div>
          <input id="file" name="file" type="file" accept=".csv" className="hidden" required />
        </label>
        <div id="file-name" className="mt-2 text-sm text-gray-500"></div>
      </div>
      
      <div className="text-sm text-gray-500 mb-4">
        <p>CSV should contain columns for ASIN, UPC (optional), and Title (optional).</p>
      </div>
      
      <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded">
        Upload and Process
      </button>
    </form>
  );
}

function StatusPanel() {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <span className="text-gray-600">Last Scan:</span>
        <span className="font-medium">Loading...</span>
      </div>
      <div className="flex justify-between items-center">
        <span className="text-gray-600">Products Tracked:</span>
        <span className="font-medium">Loading...</span>
      </div>
      <div className="flex justify-between items-center">
        <span className="text-gray-600">Websites Monitored:</span>
        <span className="font-medium">Loading...</span>
      </div>
      <div className="flex justify-between items-center">
        <span className="text-gray-600">Profitable Opportunities:</span>
        <span className="font-medium text-green-600">Loading...</span>
      </div>
      <div className="mt-4">
        <button className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded">
          Run Manual Scan
        </button>
      </div>
    </div>
  );
}

function OpportunitiesList() {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Product
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              ASIN
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Source
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Buy Price
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Sell Price
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Profit
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Margin
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          <tr>
            <td className="px-6 py-4 whitespace-nowrap">
              <div className="text-sm font-medium text-gray-900">Loading opportunities...</div>
            </td>
            <td colSpan={7}></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
